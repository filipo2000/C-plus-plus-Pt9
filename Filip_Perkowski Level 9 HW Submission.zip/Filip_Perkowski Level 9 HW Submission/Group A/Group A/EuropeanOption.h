
//Objective -> In this file we declare all the components of our European Option class

//CTRL + B let's you run a program

//Group A

#pragma once

#ifndef EuropeanOption_hpp
#define EuropeanOption_hpp

//For Group A, we are only focused on plain European Options

//Group A

//Call Option Price -> Via the Black Sholes Model -> To formula include N(x) aka the Gaussian distribution function
//With the Gaussion distribution function we have the function itself N(x) as well as d1 and d2

#include <string>
using namespace std;

//So all of these functions would work on a European Option object type; Aka object of class type European Object

class EuropeanOption
{
private:

	// Member data public for convenience; anyway, the format will 
	// not change for a plain option.

	//These are the meanings of our variables; This scheme is used throughout the HW
	double r;		// Interest rate
	double sig;		// Volatility
	double K;		// Strike price
	double T;		// Expiry date
	double b;		// Cost of carry

	string optType;	// Option name (call, put); 
	//string unam;	// Name of underlying asset


	// These functions call the Gaussian functions from the Boost Library
	double n(double x) const;
	double N(double x) const;


public:	// Public functions

	//Here we create a struct. With the pointer below it'll help extract and hand values to public members of any object of EuropeanOption class type
	struct OptionData { 
		double K_s;
		double T_s;
		double r_s;
		double sig_s;
	};

	OptionData* Optionstruct; //This is a pointer which points to a object of struct Option Data type

	EuropeanOption();							// Default call option
	EuropeanOption(double K_c, double T_c, double r_c, double sig_c, double b, string str); 
	EuropeanOption(double K_c, double T_c, double r_c, double sig_c);		
	EuropeanOption(const EuropeanOption& option2);	// Copy constructor
	virtual ~EuropeanOption(); //Deconstructor

	EuropeanOption& operator = (const EuropeanOption& option2);

	// Functions that calculate a European options price and sensitivities
	double Price(double U) const;

	// Modifier/Switch functions; Changes between a European option type to a European option put type and vice versa
	void toggle();		// Change option type (C/P, P/C)

	//These functions output the price of any given European put or call option
	//If the class object is a call then we call CallPrice() if its a put we call PutPrice()
	double CallPrice(double U) const; //Format -> European Class object type . CallPrice(double argument);
	double PutPrice(double U) const;

	//Delta value of a Call European Style Option
	// Delta value of a Put European Style Option
	//These function call the functions in the Greeks.h header file
	double Call_CallDelta(double U) const;
	double Call_PutDelta(double U) const;

	//Same as Delta but for Gamma
	double Call_CallGamma(double U) const;
	double Call_PutGamma(double U) const;

	
	double Put_Call_Parity(double assetp, double val, string str) const;

	//Call Price and Put Price functions but using our struct
	double CallPrice_struct(double S) const; 
	double PutPrice_struct(double S) const;	
};

#endif