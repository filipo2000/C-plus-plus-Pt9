//Objective -> In this file we define all the components within our European Option Class

#include "EuropeanOption.h"
#include "Normal_boost.h"
#include "Pricing.h"
#include "Greeks.h"
#include <math.h>
#include <iostream>

#include <boost/math_fwd.hpp>
using namespace boost::math;

//Our Constructors
EuropeanOption::EuropeanOption()
{
	// Initialise all default values

	// Default values
	r = 0.08;
	sig = 0.3;
	K = 65;
	T = 0.25;
	b = r;			// Black and Scholes stock option model (1973)
	optType = "C";		// European Call Option (this is the default type)
}

EuropeanOption::EuropeanOption(double K_c, double T_c, double r_c, double sig_c, double b_c, string str) {
	// Default values
	K = K_c;
	T = T_c;
	r = r_c;
	sig = sig_c;
	b = b_c;			// Black and Scholes stock option model (1973)
	optType = str;		// European Call Option (this is the default type)	
}

EuropeanOption::EuropeanOption(double K_c, double T_c, double r_c, double sig_c) {
	Optionstruct = new OptionData;
	Optionstruct->K_s = K_c;
	Optionstruct->T_s = T_c;
	Optionstruct->r_s = r_c;
	Optionstruct->sig_s = sig_c;

}


EuropeanOption::EuropeanOption(const EuropeanOption& o2)
{
	r = o2.r;
	sig = o2.sig;
	K = o2.K;
	T = o2.T;
	b = o2.b;

	optType = o2.optType;
}


EuropeanOption::~EuropeanOption()
{

}


EuropeanOption& EuropeanOption::operator = (const EuropeanOption& option2)
{

	if (this == &option2) return *this; //If argument handed is same as underlying EuropeanOption class type object

	EuropeanOption::EuropeanOption(option2); //Call the copy constructor underlying EuropeanOption class object will have all the same attribute values as option2

	return *this;
}

double EuropeanOption::n(double x) const {
	return n_BOOST(x); //n_boost() and N_BOOST are our gaussian function
}

double EuropeanOption::N(double x) const {
	return N_BOOST(x);
}

// Kernel Functions (Haug)
//Value of EuropeanOption object that's of call type
double EuropeanOption::CallPrice(double S) const
{

	return EuropeanCall(S, K, T, r, sig, b);

}

//Value of EuropeanOption object that's of put type
double EuropeanOption::PutPrice(double S) const
{
	return EuropeanPut(S, K, T, r, sig, b);
}

//These are our Calling Functions -> They direct execution to another function
double EuropeanOption::Call_CallDelta(double S) const { //This function calls the Call Delta() function from class European Option class
	return CallDelta(S, K, T, r, sig, b);
}

double EuropeanOption::Call_PutDelta(double S) const {
	return PutDelta(S, K, T, r, sig, b);
}

double EuropeanOption::Call_CallGamma(double S) const {
	return CallGamma(S, K, T, r, sig, b);
}

double EuropeanOption::Call_PutGamma(double S) const {
	return PutGamma(S, K, T, r, sig, b);
}

//These are our Struct Calling Functions
//Same as CallPrice() except that we use our struct 
double EuropeanOption::CallPrice_struct(double S) const {
	return EuropeanCall(S, (*this).Optionstruct);
}

double EuropeanOption::PutPrice_struct(double S) const {
	return EuropeanPut(S, (*this).Optionstruct);
}


// Functions that calculate option price and sensitivities
//Calculates the price of either a call or put EuropeanOption
double EuropeanOption::Price(double U) const
{


	if (optType == "C")
	{
		return CallPrice(U);
	}
	else
	{
		return PutPrice(U);
	}
}


// Modifier functions
void EuropeanOption::toggle()
{ // Change option type (C/P, P/C)

	if (optType == "C") //If we have a call then switch it to put option type a vice versa
		optType = "P";
	else
		optType = "C";
}

double EuropeanOption::Put_Call_Parity(double assetp, double val, string str) const {

	double tmp = K * exp(-r * T); //If error persists just use the respective constants

	//If our EurpoeanOption object is a call
	if (str == "C") { //Double quotes for strings -> single quotes for characters
		double C = val;
		return (C - assetp + tmp);
	}

	else { //Otheriwise we implement the put call parity formula when the underlying EuropeanOption object is a put
		double P = val;
		return (P + assetp - tmp);
	}

}
