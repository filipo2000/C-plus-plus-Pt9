#pragma once

//Objective -> In this header file we declare and define all the functions that will help us price our EuropeanOption class objects(put and call versions)

//Relationship between a European Call and Put Stock options price is called the Put-Call Parity
//This is -> C + Ke^-rt = P + S -> Where P is the European Put Options price ; C -> European Call Option Price. S -> Current Stock price


//In this header file we have the functions which return the value for a given European Call/Put
//Caller functions in EuropeanOption.h call functions from this header file

//Group A

#pragma once

#ifndef Pricing_h
#define Pricing_h


#include <cmath>
#include "Normal_boost.h"
#include "EuropeanOption.h"

double EuropeanCall(double S, EuropeanOption::OptionData* c) { //This calculates any European Call Option using our struct object

	double K = c->K_s; //Using our optiondata pointer to implement values into our underlying EuropeanOption class object
	double T = c->T_s;
	double r = c->r_s;
	double sig = c->sig_s;
	double b = r; //To designate the Black Scholes stock options model

	double temp = sig * sqrt(T);

	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / temp; //d1 component of our formula

	double d2 = d1 - temp; //d2 component of our formula

	return (S * exp((b - r) * T) * N_BOOST(d1)) - (K * exp(-r * T) * N_BOOST(d2));

}


double EuropeanPut(double S, EuropeanOption::OptionData* c) { //This calculates European Put Option using our struct pointer

	double K = c->K_s; //Here we create local variables whose values are fetched from struct object c
	double T = c->T_s;
	double r = c->r_s;
	double sig = c->sig_s;
	double b = r;

	double temp = sig * sqrt(T);
	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / temp;
	double d2 = d1 - temp;

	return (K * exp(-r * T) * N_BOOST(-d2)) - (S * exp((b - r) * T) * N_BOOST(-d1)); 


}

//Without the use of our struct + pointer; 
double EuropeanCall(double S, double K, double T, double r, double sig, double b) { //This calculates European Call Option Price

	double tmp = sig * sqrt(T); //Search up the formula online for this one for example -> sig(STDEV) * square root of T(Time)
	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / tmp;
	double d2 = d1 - tmp;

	return (S * exp((b - r) * T) * N_BOOST(d1)) - (K * exp(-r * T) * N_BOOST(d2));
}

//Without the use of our struct + pointer
double EuropeanPut(double S, double K, double T, double r, double sig, double b) { //This calculates European Put Option
	double tmp = sig * sqrt(T); //Search up the formula online for this one for example -> sig(STDEV) * square root of T(Time)
	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / tmp;
	double d2 = d1 - tmp;

	return (K * exp(-r * T) * N_BOOST(-d2)) - (S * exp((b - r) * T) * N_BOOST(-d1));




}




#endif