
//Objective -> In this file we declare and define all the Greeks components of our Put and Call Options
//Greeks include -> Delta,Gamma, Vega

//Group A

#pragma once

#ifndef Greek_h
#define Greeks_h

#include "Normal_boost.h"
#include <math.h>

//Option Sensitivness aka The Greeks -> These are partial derivatives to the Black Scholes Model with respect to one of the parameters

//Gamma Function Formula is the same for a call or put option
//Delta Function Formula is the same for a call or put option

//Paramters and their role are the same as portrayed in EuropeanOption.h header file
//S reffers to the asset price
//Delta -> Reffers to how much the value of an option changes when the stock's price increases by 1 dollar 

//Implementing the Delta function for a call European Option 
double CallDelta(double S, double K, double T, double r, double sig, double b) {
	double temp = sig * sqrt(T); //Make sure you understand these formulas
	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / temp;
	return exp((b - r) * T) * N_BOOST(d1); //You need to include the Boost Library; Make sure you include the BOOST Library for each file in HW 9
} //Return statement is the Delta Function formula

//Finds the delta of a European Put Option
//Same idea as above but for any European Put Option
double PutDelta(double S, double K, double T, double r, double sig, double b) {
	double temp = sig * sqrt(T);
	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / temp;
	return exp((b - r) * T) * (N_BOOST(d1) - 1.0); //You need to include the Boost Library; Make sure you include the BOOST Library for each file in HW 9
}


//Here we calculate the Gamma value for any European Call Option
//Gamma -> This measures the rate of change of an option greek delta
double CallGamma(double S, double K, double T, double r, double sig, double b) {
	double temp = sig * sqrt(T);
	double d1 = (log(S / K) + (b + (sig * sig) * .5) * T) / temp; //This is our d1 in the Gamma Formula
	double d2 = d1 - temp;
	return (n_BOOST(d1) * (exp(b - r) * T)) / (S * temp); //You need to include the Boost Library; Make sure you include the BOOST Library for each file in HW 9
} //return statement is just the gamma function formula

//Here we calculate the Gamma value for any European Call Option

double PutGamma(double S, double K, double T, double r, double sig, double b) {
	return CallGamma(S, K, T, r, sig, b); //So calling PutDelta(arguments to define parameters of PutDelta initially) calls Call Gamma with same arguments that we used to initially call PutDelta
}

//PutDelta is same as CallGamma()




#endif