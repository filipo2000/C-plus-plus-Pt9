#include "EuropeanOption.h"
#include "Mesher.h"
#include "Global_print.h" //This header file includes the print() function with the nested vector parameter which prints out our matrix 
//#include "Greeks.h"
#include <iostream>
#include <fstream>
#include <vector>

//Comments contained in each Group explain my justification for my design decisions 

//The program runs. Now fix it up and add some finishing touches to it; Run through to make sure everything runs good. Run it part by part

//First 4 parts should be done for the 4 batches

//The 2nd phase of Part A aka the second 4 parts should be done using the batch K = 100, S = 105 ...


//n(x) - Normal Gaussian prob density function   //-> Both of these are supported by the Boost Library
//N(x) - Cumulative normal distribution function

//Objective -> In this file we test our files

using namespace std;
using std::vector;

//Here we have our 2 divided difference functions for Part D of the 2nd Part of Group A
void d_div() {
	double T = 0.5; double K = 100; double sig = 0.36; double r = 0.1; double S = 105; double b = 0;
	EuropeanOption Batch_c(K, T, r, sig, b, "C"); //Our EuropeanOption object

	double h;
	cout << "Value for h to find deltas(delta div difference function) : ";
	cin >> h;

	double delt_c = Batch_c.Call_CallDelta(S);

	Batch_c.toggle();

	double delt_p = Batch_c.Call_PutDelta(S);

	std::cout << "Delta of Call Option using Div Difference Function: " << (delt_c * (S + h) - delt_c * (S - h)) / (2 * h) << std::endl; //Implementing the Delta Function
	std::cout << "Delta of Put Option using Div Difference Function: " << (delt_p * (S + h) - delt_p * (S - h)) / (2 * h) << std::endl;
}

void g_div() {
	double T = 0.5; double K = 100; double sig = 0.36; double r = 0.1; double S = 105; double b = 0;


	EuropeanOption Batch_l(K, T, r, sig, b, "C"); //Our EuropeanOption object

	double h;
	cout << "Value for h to find gammas(gamma div difference function): ";
	cin >> h;

	double gamma_c = Batch_l.Call_CallGamma(S);

	Batch_l.toggle();

	double gamma_p = Batch_l.Call_PutGamma(S);

	std::cout << "Gamma of Call Option using Div Difference Function: " << (gamma_c * (S + h) - 2 * gamma_c * S + gamma_c * (S - h)) / (h * h) << std::endl; //Implmenting the Gamma Function
	std::cout << "Gamma of Put Option using Div Difference Function: " << (gamma_p * (S + h) - 2 * gamma_p * S + gamma_p * (S - h)) / (h * h) << std::endl;



}


/* Cost of carry factor b must be included in formulae depending on the
   derivative type. These are used in the generalised Black-Scholes formula.
   If r is the risk-free interest and q is the continuous dividend yield then
   the cost-of-carry b per derivative type is:

	a) Black-Scholes (1973) stock option model: b = r
	b) b = r - q Merton (1973) stock option model with continuous dividend yield
	c) b = 0 Black (1976) futures option model
	d) b = r - rf Garman and Kohlhagen (1983) currency option model, where rf is the
	   'foreign' interest rate
*/


//I commented each code block so that I can run each solution individually. This wa I keep things tidy

int main()
{

	//std::cout << "Group A: European Options" << '\n';

	/*
	//Working with the 1st Batch

	//Part A of 1st Batch
	double T1 = 0.25; double K1 = 65; double sig1 = 0.30; double r1 = 0.08; double S1 = 60; double b1 = r1;
	EuropeanOption Batch2(K1, T1, r1, sig1, b1, "C"); //Creating an object of class type European Option
	double c1 = Batch2.Price(S1); //Price of call version of our European object class type object Batch2
	Batch2.toggle();//Now this object is a European Put option
	double p1 = Batch2.Price(S1); //Finding the price of this put option now it got converted from a call to a put via the toggle() function

	std::cout << "******" << '\n';
	std::cout << "** Put and Call Price For Batch 1 **" << std::endl;
	std::cout << "Call Price For Batch 1: " << c1 << std::endl;
	std::cout << "Put Price For Batch 1: " << p1 << std::endl; //C2 and P2 are both 7.9657 it works well

	

	//Part B on 1st Batch
	//Using Put Call Parity
	std::cout << "Using Put Call Parity -> Call: " << Batch2.Put_Call_Parity(S1, p1, "P") << std::endl;
	std::cout << "Using Put Call Parity -> Put: " << Batch2.Put_Call_Parity(S1, c1, "C") << std::endl;
	bool resi_p = (p1 == (Batch2.Put_Call_Parity(S1, c1, "C")));
	std::cout << "Checking if Put Call Parity is satisfied: " << resi_p << std::endl; //Checking if both are equal

	 */
	

	/*
	 //Part C Of 1st Batch -> Numbers are perfect you just need to put them into a matrix/vector
	//5th Part of assessing 1st Batch; //Call and Put Price for A European Option Ranging From 60 to 70
	double T1 = 0.25; double K1 = 65; double sig1 = 0.30; double r1 = 0.08; double S1 = 60; double b1 = r1;
	vector<double> Svector; //This is a vector of S value
	for (int i = 10; i <= 20; i++) { //10 iterations
		EuropeanOption Batch1r(K1, T1, r1, sig1);
		double C1 = Batch1r.CallPrice_struct(S1);
		double P1 = Batch1r.PutPrice_struct(S1);
		std::cout << "Stock Price: " << S1 << " Call Option Price : " << C1 << " Put Option Price : " << P1 << std::endl;

		S1 = S1 + 1;    //The Part is perfect you just need to implement the numbers into a matrix
		Svector.push_back(C1); //Pushing the Call and Put Price for each Stock Price into our Vector
		Svector.push_back(P1);
		
	}
	
	//Checking our vector
	for (int i = 0; i < Svector.size(); i++) {
		std::cout << Svector[i] << std::endl;
	}

	*/

	
	/*
		//Part D of assessing 1st Batch;
		//So here we have printed out the Stock Price and the corresponding European Put or Calls value based on the value of the if statement for that iteration
		double T1 = 0.25; double K1 = 65; double sig1 = 0.30; double r1 = 0.08; double S1 = 60; double b1 = r1;
	vector<double> Svector = mesher(10, 50, 1); //This is a vector of S value
	int Ssize = Svector.size();

	vector<vector<double>> new_matrix(Ssize, vector<double>(2)); //Here's our matrix; Ssize denotes the number of nested vector<double> of size 2 in our outer vector aka matrix


	EuropeanOption Batch1d(K1, T1, r1, sig1); //Using the Expiry Time, volatility etc. as our parameters now for our European Option class object

	for (int i = 0; i < Ssize; i++) {
		for (int k = 0; k < 2; ++k) {
			if (k == 0) {
				new_matrix[i][k] = Batch1d.CallPrice_struct(Svector[i]); //Inputting our call and put option prices into our matrix

			}
			else {
				new_matrix[i][k] = Batch1d.PutPrice_struct(Svector[i]);
			}
		}
	}
	print(new_matrix); //Using the print() function to print out all the components of this nested vector; This print() function will call the simpler print() function also
	//What's printed out is the stock/asset price and the corresponding put/call option value based on the above if statement. One or the other

	*/
	




	/*
	//Working with the 2nd Batch
		//Part A on 2nd Batch
			double T2 = 1.0; double K2 = 100; double sig2 = 0.2; double r2 = 0.00; double S2 = 100; double b2 = r2;
			EuropeanOption Batch2(K2, T2, r2, sig2, b2, "C"); //Creating an object of class type European Option

			double c2 = Batch2.Price(S2); //Price of call version of our European object class type object Batch2
			Batch2.toggle();//Now this object is a European Put option
			double p2 = Batch2.Price(S2); //Finding the price of this put option now it got converted from a call to a put via the toggle() function

			std::cout << "******" << '\n';
			std::cout << "** Put and Call Price For Batch 1 **" << std::endl;
			std::cout << "Call Price For Batch 1: " << c2 << std::endl;
			std::cout << "Put Price For Batch 1: " << p2 << std::endl; //C2 and P2 are both 7.9657 it works well

			//Part B on 2nd Batch
			//Using Put Call Parity
			std::cout << "Using Put Call Parity -> Call: " << Batch2.Put_Call_Parity(S2, p2, "P") << std::endl;
			std::cout << "Using Put Call Parity -> Put: " << Batch2.Put_Call_Parity(S2, c2, "C") << std::endl;
			bool resi_p = (p2 == (Batch2.Put_Call_Parity(S2, p2, "P")));
			std::cout << "Checking if Put Call Parity is satisfied: " << resi_p << std::endl; //Checking if both are equal

	*/


		/*
		//Part C of 2nd Batch -> We need to somehow input these call and put value options into a matrix
		double T2 = 1.0; double K2 = 100; double sig2 = 0.2; double r2 = 0.00; double S2 = 100; double b2 = r2;
		vector<double> Svector2; //This is a vector of S value
		for (int i = 0; i <= 10; i++) { //10 iterations
		EuropeanOption Batch1r(K2, T2, r2, sig2);
		double C2 = Batch1r.CallPrice_struct(S2);
		double P2 = Batch1r.PutPrice_struct(S2);
		std::cout << "Stock Price: " << S2 << " Call Option Price : " << C2 << " Put Option Price : " << P2 << std::endl;
		S2 = S2 + 1;    //The Part is perfect you just need to implement the numbers into a matrix
		Svector2.push_back(C2); //Pushing the Call and Put Price for each Stock Price into our Vector
		Svector2.push_back(P2);
}
	
	
	//Checking our vector
	for (int i = 0; i < Svector2.size(); i++) { //Elements of vector are followed by Call Price -> Put Price of Option 1 -> Call Price of Option 2 -> Put Price of Option2 etc.
		std::cout << Svector2[i] << std::endl;
	}
		

		*/
		

	
	/*
		//Part D of assessing 2nd Batch;
		//So here we have printed out the Stock Price and the corresponding European Put or Calls value based on the value of the if statement for that iteration
double T2 = 1.0; double K2 = 100; double sig2 = 0.2; double r2 = 0.00; double S2 = 100; double b2 = r2;
	vector<double> Svector2 = mesher(10, 50, 1); //This is a vector of S value
	int Ssize2 = Svector2.size();

	vector<vector<double>> new_matrix2(Ssize2, vector<double>(2)); //Here's our matrix


	EuropeanOption Batch1d(K2, T2, r2, sig2); //Using the Expiry Time, volatility etc. as our parameters now for our European Option class object

	for (int i = 0; i < Ssize2; i++) {
		for (int k = 0; k < 2; ++k) {
			if (k == 0) {
				new_matrix2[i][k] = Batch1d.CallPrice_struct(Svector2[i]);

			}
			else {
				new_matrix2[i][k] = Batch1d.PutPrice_struct(Svector2[i]);
			}
		}
	}
	print(new_matrix2); //Using the print() function to print out all the components of this nested vector; This print() function will call the simpler print() function also
	//What's printed out is the stock/asset price and the corresponding put/call option value based on the above if statement. One or the other

	*/


	/*
	//Working with the 3rd Batch
	//Part A of assessing 3rd Batch
		double T3 = 1.0; double K3 = 10; double sig3 = 0.50; double r3 = 0.12; double S3 = 5; double b3 = r3;
		EuropeanOption Batch3(K3, T3, r3, sig3, b3, "C"); //Creating an object of class type European Option
		double c3 = Batch3.Price(S3); //Price of call version of our European object class type object Batch2
		Batch3.toggle();//Now this object is a European Put option
		double p3 = Batch3.Price(S3); //Finding the price of this put option now it got converted from a call to a put via the toggle() function

		std::cout << "******" << '\n';
		std::cout << "** Put and Call Price For Batch 1 **" << std::endl;
		std::cout << "Call Price For Batch 1: " << c3 << std::endl;
		std::cout << "Put Price For Batch 1: " << p3 << std::endl; //C2 and P2 are both 7.9657 it works well

		//Part B on 2nd Batch
		//Using Put Call Parity
		std::cout << "Using Put Call Parity -> Call: " << Batch3.Put_Call_Parity(S3, p3, "P") << std::endl;
		std::cout << "Using Put Call Parity -> Put: " << Batch3.Put_Call_Parity(S3, c3, "C") << std::endl;
		bool resi_p = (p3 == (Batch3.Put_Call_Parity(S3, c3, "C")));
		std::cout << "Checking if Put Call Parity is satisfied: " << resi_p << std::endl; //Checking if both are equal

	*/
	


	/*
		//We could create a mesh array using mesher() and implement a h value increment between each element value in the vector returned by function mesher()
		//Part C for Batch 3
		//5th Part of assessing 1st Batch; //Call and Put Price for A European Option Ranging From 60 to 70
		double T3 = 1.0; double K3 = 10; double sig3 = 0.50; double r3 = 0.12; double S3 = 5; double b3 = r3; //We start from 5 since that's tht estarting price of EuropeanOption object Batch3(namme of the class object)
		vector<double> Svector3;
		for (int i = 0; i < 10; i++) { //10 iterations
			EuropeanOption Batch3(K3, T3, r3, sig3); //Local variable
			double C3 = Batch3.CallPrice_struct(S3);
			double P3 = Batch3.PutPrice_struct(S3);
			std::cout << "Stock Price: " << S3 << " Call Option Price : " << C3 << " Put Option Price : " << P3 << std::endl;
			S3 = S3 + 1;
			Svector3.push_back(C3);
			Svector3.push_back(P3);

			}
		for (int i = 0; i < Svector3.size(); i++) {
			std::cout << Svector3[i] << std::endl;
		}

	*/


	/*
		//Part D of assessing 3rd Batch;
		
		//So here we have printed out the Stock Price and the corresponding European Put or Calls value based on the value of the if statement for that iteration
		double T3 = 1.0; double K3 = 10; double sig3 = 0.50; double r3 = 0.12; double S3 = 5; double b3 = r3;
		vector<double> Svector3 = mesher(10, 50, 1); //This is a vector of S value
		int Ssize3 = Svector3.size();

		vector<vector<double>> new_matrix3(Ssize3, vector<double>(2)); //Here's our matrix


		EuropeanOption Batch3(K3, T3, r3, sig3);

		for (int i = 0; i < Ssize3; i++) {
			for (int k = 0; k < 2; ++k) {
				if (k == 0) {
					new_matrix3[i][k] = Batch3.CallPrice_struct(Svector3[i]);

				}
				else {
					new_matrix3[i][k] = Batch3.PutPrice_struct(Svector3[i]);
				}
			}
		}
		print(new_matrix3); //Using the print() function to print out all the components of this nested vector; This print() function will call the simpler print() function also

	*/		



		/*
		//Working with the 4th Batch

		//Part A of assessing 3rd Batch
			double T4 = 30.0; double K4 = 100; double sig4 = 0.30; double r4 = 0.08; double S4 = 100; double b4 = r4;
			EuropeanOption Batch4(K4, T4, r4, sig4, b4, "C"); //Creating an object of class type European Option
			double c4 = Batch4.Price(S4); //Price of call version of our European object class type object Batch2
			Batch4.toggle();//Now this object is a European Put option
			double p4 = Batch4.Price(S4); //Finding the price of this put option now it got converted from a call to a put via the toggle() function

			std::cout << "******" << '\n';
			std::cout << "** Put and Call Price For Batch 1 **" << std::endl;
			std::cout << "Call Price For Batch 1: " << c4 << std::endl;
			std::cout << "Put Price For Batch 1: " << p4 << std::endl; //C2 and P2 are both 7.9657 it works well

			//Part B on 2nd Batch
			//Using Put Call Parity
			std::cout << "Using Put Call Parity -> Call: " << Batch4.Put_Call_Parity(S4, p4, "P") << std::endl;
			std::cout << "Using Put Call Parity -> Put: " << Batch4.Put_Call_Parity(S4, c4, "C") << std::endl;
			bool resi_p = (c4 == (Batch4.Put_Call_Parity(S4, p4, "P")));
			std::cout << "Checking if Put Call Parity is satisfied: " << resi_p << std::endl; //Checking if both are equal

	
		*/

		/*
			//Part C for 4th Batch
			double T4 = 30.0; double K4 = 100; double sig4 = 0.30; double r4 = 0.08; double S4 = 100; double b4 = r4;
			vector<double> Svector4;
			for (int i = 0; i < 10; i++) { //10 iterations
			EuropeanOption Batch3(K4, T4, r4, sig4); //Local variable
			double C4 = Batch3.CallPrice_struct(S4);
			double P4 = Batch3.PutPrice_struct(S4);
			std::cout << "Stock Price: " << S4 << " Call Option Price : " << C4 << " Put Option Price : " << P4 << std::endl;
			S4 = S4 + 1;
			Svector4.push_back(C4);
			Svector4.push_back(P4);

			}

			for (int i = 0; i < Svector4.size(); i++) {
			std::cout << Svector4[i] << std::endl;
			}

		*/


		/*
		//Part D of assessing 4th Batch;
			//So here we have printed out the Stock Price and the corresponding European Put or Calls value based on the value of the if statement for that iteration
			double T4 = 30.0; double K4 = 100; double sig4 = 0.30; double r4 = 0.08; double S4 = 100; double b4 = r4;
			vector<double> Svector4 = mesher(10, 50, 1); //This is a vector of S value
			int Ssize4 = Svector4.size();

			vector<vector<double>> new_matrix4(Ssize4, vector<double>(2)); //Here's our matrix


			EuropeanOption Batch4(K4, T4, r4, sig4);

			for (int i = 0; i < Ssize4; i++) {
				for (int k = 0; k < 2; ++k) {
					if (k == 0) {
						new_matrix4[i][k] = Batch4.CallPrice_struct(Svector4[i]);

					}
					else {
						new_matrix4[i][k] = Batch4.PutPrice_struct(Svector4[i]);
					}
				}
			}
			print(new_matrix4); //Using the print() function to print out all the components of this nested vector; This print() function will call the simpler print() function also

		*/



			//2ND PART OF GROUP A


	/*
	  //Part A

	  double T = 0.5; double K = 100; double sig = 0.36; double r = 0.1; double S = 105; double b = 0; //Change Sv2 back to 105
	  EuropeanOption Batch2a(K, T, r, sig, b, "C");

	  //cout statements using the greeks(finding the greek values) on obj2
	  std::cout << "Gamma Call: " << Batch2a.Call_CallGamma(S) << std::endl;
	  std::cout << "Gamma Put: " << Batch2a.Call_PutGamma(S) << std::endl;
	  std::cout << "Delta Call: " << Batch2a.Call_CallDelta(S) << std::endl; //Delta Call should equal .5946; Works well
	  std::cout <<"Delta Put: " << Batch2a.Call_PutDelta(S) << std::endl; //Delta Put should equal -.3566; Works well

	  
	  */



	  /*
		//Part B //Call Delta values for a range of S values
			double T = 0.5; double K = 100; double sig = 0.36; double r = 0.1; double S = 105; double b = 0; //This is the batch we want to work with
			//Here we loop through our Sv2 -> stock price and ouput the respective European Call Option price as well as the Delta component of the call option price
			vector<double> Svector2;
			for (int i = 0; i < 10; i++) { //10 iterations
				EuropeanOption Batch3(K, T, r, sig); //Local variable
				double C3 = Batch3.CallPrice_struct(S);
				double P3 = Batch3.Call_CallDelta(S);
				std::cout << "Stock Price: " << S << " Call Option Price : " << C3 << " Delta Price of Call Option : " << P3 << std::endl;
				Svector2.push_back(C3); //Pushing back C3(Call option price of our EuropeanOption class object Batch3 and incrementing this objects stock/asset price each iteration which yields a new option price for our underlying class object
				S = S + 1;

				}
			
			for (int i = 0; i < Svector2.size(); i++) {
				std::cout << Svector2[i] << std::endl;
			}
		
		 */


		/*
		   //Part C
		   double T = 0.5; double K = 100; double sig = 0.36; double r = 0.1; double Sv2 = 105; double b = 0;
		   vector<double> Svector = mesher(10, 50, 1); //This is our vector which holds our S value's; So we will go from 10 to 50 incrementing by 1 for each iteration
		   int Svecsize = Svector.size(); //Svector is a vector that contains values 10,11,12...  48,49,50 

		   EuropeanOption obj2_b(K, T, r, sig, b, "c");

		   vector<vector<double>> result_A2_b(Svecsize,vector<double>(2)); //Our nested matrix will have Svecsize elements each of which are double vectors of size 2

		   for (int i = 0; i < Svecsize; ++i) {
			   for (int k = 0; k < 2; ++k) {
				   if (k == 0)  //Indexing Svector[i] we get the corresponding asset/stock price
					   result_A2_b[i][k] = obj2_b.Call_CallDelta(Svector[i]); //Here we are supplying values to our matrix
				   else
					   result_A2_b[i][k] = obj2_b.Call_PutDelta(Svector[i]); //Supply element
					   }
				   }
		   print(result_A2_b); //printing out our matrix by using the print() function from the Global_print.h file; argument is a nested vector
		   //Here we get our call deltas and our put deltas
		  
		 */ 



		   /*
			 //Part D
			 //Our Delta divided differences function() is above the main()


			   double T = 0.5; double K = 100; double sig = 0.36; double r = 0.1; double S = 105; double b = 0;
			   EuropeanOption Batch2d(K, T, r, sig, b, "C"); //Our EuropeanOption object

			   //Finding the Greeks using the functions
			   std::cout << "Call Gamma Value: " << Batch2d.Call_CallGamma(S) << std::endl;
			   std::cout << "Put Gamma Value: " << Batch2d.Call_PutGamma(S) << std::endl;
			   std::cout << "Call Delta Value: " << Batch2d.Call_CallDelta(S) << std::endl; //Delta Call should equal .5946; Works well
			   std::cout << "Put Delta Value: " << Batch2d.Call_PutDelta(S) << std::endl; //Delta Put should equal -.3566; Works well

			   //Finding the Greeks using our 2 divided difference functions()
			   d_div();
			   g_div();

			//Comparing both methods when computing delta, they match. Computing gamma using both there's a difference in value

			*/
		  
			

}