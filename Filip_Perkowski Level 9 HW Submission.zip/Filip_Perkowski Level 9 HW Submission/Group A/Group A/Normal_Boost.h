#pragma once

//Objective -> In this file we find the PDF's and CDF's of our Normal Distribution variable

#ifndef Normal_boost_h
#define Normal_boost_h

//Including the proper header files
#include <iostream>
#include<boost/math/distributions/normal.hpp>
#include <boost/math/distributions.hpp> //Including all the remaining distruibutions
using namespace boost::math;

//0.0 mean and 1.0 Stdev to designate a normal distribution
double N_BOOST(double x) {
	normal_distribution<> mynorm(0.0, 1.0); //Creating our normal distribution variable
	return cdf(mynorm, x);
}

double n_BOOST(double y) {
	normal_distribution<> mynorm(0.0, 1.0); //Creating our normal distribution variable
	return pdf(mynorm, y);
}








#endif