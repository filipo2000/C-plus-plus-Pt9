#pragma once

//Objective -> In this file we declare and define all the components within our Mesher class

//For the matrix pricer/matrix pricing
//We should have a p*n matrix; Where p -> number of rows equal to the number of option parameters and n->number of options
//Matrix m is inputed into the pricer mechansim and what's outputted is a vector consisting of prices for all the option(so vector would contain n elements since we have n rows)
//Objective - > In our mesher header file, we have a mesher() function which constructs a mesh array of double values between a min val and a max val, incrementing by some value h 


#ifndef Mesher_H
#define Mesher_H
using namespace std;

#include <vector>
#include <iostream>

//Within our mesher function we return a vector which we construct using the argument handed in when calling the function. Vector's values range from min_val to max_val. Difference between each elements value is inc(our increment)
std::vector<double> mesher(double min_val, double max_val, double inc)
{
	// NB Full array (includes end points)
	double rmin = min_val;
	double rmax = max_val;
	int n_elements = (rmax - rmin) / (inc + 1); //This variable value corresponds to the number of elements which will be in our vector which we will create + this function will return

	std::vector<double> xarr(n_elements);
	xarr[0] = rmin;
	xarr[xarr.size() - 1] = rmax;

	for (int j = 1; j < xarr.size() - 1; ++j)
	{
		xarr[j] = xarr[j - 1] + inc;
	}

	return xarr;
}



#endif