#pragma once

//Objective -> In this file we translate the Standrd Error and Standard Deviation formulas into code

#ifndef SD_SDE
#define SD_SDE


#include <string>
#include <iostream>
#include <vector>
#include <cmath>

#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>

using namespace std;
using boost::tuple;

//Here we translate SD(Standard Deviation) and SE(Standard Error) theory formulas into code

//r = risk free rate; T = time to expriation
//Each element in vector input is the value of the option for that given Monte Carlo simulation. In which the index + 1 denotes the Monte Carlo simulation count
boost::tuple<double, double> getSD_and_SE(vector<double> c, double r, double T) { //Vector input, interest rate and time to expiry
	double sz = c.size(); //This is M in our SE and SD mathematical formulas //Size of argument -> value handed to the parameter; input_size -> value is the number of Monte Carlo Simulations
	double sum_prices = 0; 
	double sum_square_prices = 0;

	for (int i = 0; i < sz; i++) {

		sum_prices += c[i];
		sum_square_prices += pow(c[i],2);


	}

	double root = sqrt(sum_square_prices - (pow(sum_prices, 2) / sz)); //Implementing the theory from Part D to code
	double SD = root * exp(-r * T) / (sz - 1.0); //Our SD value
	double SE = SD / sqrt(sz); //Our SE 

	return boost::tuple<double, double>(SD, SE); //Return a tuple which holds both of our values


	//We get the SD and SE for a given option object over a number of Monte Carlo simulations; M = Number of Monte Carlo Sim
	//SD and SD in terms of the options price over the course of these simulations
}




#endif










































