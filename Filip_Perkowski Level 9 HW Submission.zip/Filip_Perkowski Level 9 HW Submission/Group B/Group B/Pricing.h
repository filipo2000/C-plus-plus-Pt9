//Objective -> In this header we include and define all the functions that we will use to price our PAmericanOption class objects

#pragma once

#ifndef PRICING_HPP
#define PRICING_HPP

#include "PAmericanOption.h"
#include <iostream>
#include <cmath>

using namespace std;

//2 versions one which uses our struct structre + pointer, the other is a generic functions parameters will hand in values to the components of the AmericanOption class object(batch components)

double PerpetualCall(double S, PAmericanOption::OptionData* c) {
	double K = c->K_s;
	double r = c->r_s;
	double sig = c->sig_s;
	double b = c->b_s;

	double sig2 = sig * sig;
	double fac = (b / sig2) - 0.5; fac *= fac;

	double y1 = 0.5 - (b / sig2) + sqrt(fac + 2.0 * r / sig2);

	if (1.0 == y1) {
		return S;
	}


	double fac2 = ((y1 - 1.0) * S) / (y1 * K);
	double g = K * pow(fac2, y1) / (y1 - 1.0); //AmericanOption Call price formula


	return g;

}


double PerpetualPut(double S, PAmericanOption::OptionData* c) {
	double K = c->K_s;
	double r = c->r_s;
	double sig = c->sig_s;
	double b = c->b_s;

	double sig2 = sig * sig;
	double fac = (b / sig2) - 0.5; fac *= fac;

	double y2 = 0.5 - (b / sig2) - sqrt(fac + 2.0 * r / sig2);

	if (0.0 == y2) {
		return S;
	}


	double fac2 = ((y2 - 1.0) * S) / (y2 * K);
	double g = K * pow(fac2, y2) / (1.0 - y2); //AmericanOption Put price formula


	return g;

}


double PerpetualCall(double K, double S, double sig, double r, double b) {

	double sig2 = sig * sig;
	double fac = (b / sig2) - 0.5; fac *= fac;

	double y1 = 0.5 - (b / sig2) + sqrt(fac + 2.0 * r / sig2);

	if (1.0 == y1) {
		return S;
	}


	double fac2 = ((y1 - 1.0) * S) / (y1 * K);
	double g = K * pow(fac2, y1) / (y1 - 1.0);


	return g;

}


double PerpetualPut(double K, double S, double sig, double r, double b) {

	double sig2 = sig * sig;
	double fac = (b / sig2) - 0.5; fac *= fac;

	double y2 = 0.5 - (b / sig2) - sqrt(fac + 2.0 * r / sig2);

	if (0.0 == y2) {
		return S;
	}


	double fac2 = ((y2 - 1.0) * S) / (y2 * K);
	double g = K * pow(fac2, y2) / (1.0 - y2);


	return g;

}





#endif