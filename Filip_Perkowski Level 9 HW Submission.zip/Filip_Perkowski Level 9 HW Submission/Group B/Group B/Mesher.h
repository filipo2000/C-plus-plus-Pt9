#pragma once

//Objective -> In this file we declare and define all the components within our Mesher class


#ifndef MESHER_H
#define MESHER_H
using namespace std;

#include <vector>
#include <iostream>

std::vector<double> mesher(double min_val, double max_val, double h)
{
	// NB Full array (includes end points)
	double rmin = min_val;
	double rmax = max_val;
	int n_elements = (rmax - rmin) / (h + 1); //This variable value corresponds to the number of elements which will be in our vector which we will create + this function will return

	std::vector<double> xarr(n_elements);
	xarr[0] = rmin;
	xarr[xarr.size() - 1] = rmax;

	for (int j = 1; j < xarr.size() - 1; ++j)
	{
		xarr[j] = xarr[j - 1] + h;
	}

	return xarr;
}



#endif