#pragma once

//Objective -> In this file we find the PDF's and CDF's of our Normal Distribution variable

#ifndef NORMAL_FUNCTION_HPP
#define NORMAL_FUNCTION_HPP

//Including the proper header files
#include <iostream>
#include<boost/math/distributions/normal.hpp>
#include <boost/math/distributions.hpp> //Including all the remaining distruibutions

using namespace boost::math;


double N_BOOST(double x) {
	normal_distribution<> mynorm(0.0, 1.0); //CDF of Normal Distribution
	return cdf(mynorm, x);
}

double n_BOOST(double y) {
	normal_distribution<> mynorm(0.0, 1.0); //PDF of Normal Distribution 
	return pdf(mynorm, y);
}








#endif