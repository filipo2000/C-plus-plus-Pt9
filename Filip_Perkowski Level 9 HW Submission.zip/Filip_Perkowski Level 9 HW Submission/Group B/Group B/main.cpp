#include <iostream>
#include <vector>
#include "PAmericanOption.h"
#include "Mesher.h"
#include "Global_print.h"

using namespace std;

//Objective -> We test our files


int main() {

	//Part A Of Group B -> Formulas in are in pricing.h

	/*
	//Part B of Group B
	double K = 100; double sig = 0.1; double r = 0.1; double b = 0.02; double S = 110;

	PAmericanOption Batch1(K, sig, r, b);
	cout << "Value of Call -> Struct: " << Batch1.Call_Price_Struct(S) << std::endl;
	cout << "Valid of Put -> Struct: " << Batch1.Put_Price_Struct(S) << std::endl;
	*/
	


	
	 /*
	//Part C of Group B

	double K = 100; double sig = 0.1; double r = 0.1; double b = 0.02; double S = 110; //double b = r;
	vector<double> Svector;
	for (int i = 0; i <= 11; i++) { //10 iterations
		PAmericanOption Batch1c(K, sig, r, b);
		double C1 = Batch1c.Call_Price_Struct(S);
		double P1 = Batch1c.Put_Price_Struct(S);
		std::cout << "Stock Price: " << S << " Call Option Price : " << C1 << " Put Option Price : " << P1 << std::endl;

		S = S + 1;    //The Part is perfect you just need to implement the numbers into a matrix
		Svector.push_back(C1);
		Svector.push_back(P1);

	}
	
	for (int i = 0; i < Svector.size(); i++) {
		std::cout << Svector[i] << std::endl;
	}

	*/


	/*
	
	//Part D of Group B
	double K = 100; double sig = 0.1; double r = 0.1; double S = 110; double b = r;
	vector<double> Svector = mesher(10, 50, 1); //This is a vector of S value
	int Ssize = Svector.size();

	vector<vector<double>> new_matrix(Ssize, vector<double>(2)); //Here's our matrix


	PAmericanOption Batch1d(K, sig, r, b); //Using the Expiry Time, volatility etc. as our parameters now for our European Option class object

	for (int i = 0; i < Ssize; i++) {
		for (int k = 0; k < 2; ++k) {
			if (k == 0) {
				new_matrix[i][k] = Batch1d.Call_Price_Struct(Svector[i]); //By calling Call_Price_Struct and Put_Price_Struct we are calling PerpetualCall() and PerpetualPut()
																		  //The body of Call_Price_Struct and Put_Price_Struct calls PerpetualCall() and PerpetualPut()
			}
			else {
				new_matrix[i][k] = Batch1d.Put_Price_Struct(Svector[i]);
			}
		}
	}
	print(new_matrix); //Using the print() function to print out all the components of this nested vector; This print() function will call the simpler print() function also
	//What's printed out is the stock/asset price and the corresponding put/call option value based on the above if statement. One or the other

	
	*/

}

