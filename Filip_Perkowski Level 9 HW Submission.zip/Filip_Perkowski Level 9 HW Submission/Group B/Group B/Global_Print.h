#pragma once

//Objective -> In our Global_Print header file we print out the vectors and nested vectors when handed into the print() functions as arguments

#ifndef Global_PRINT_H
#define Global_PRINT_H


#include <vector>
#include <iostream>
using namespace std;

//Using the print() function we print out the components of the vector which we passed in as an argument when we called print() in our main function main()
void print(const vector<double>& c) {
	for (int i = 0; i < c.size(); ++i) {
		cout << c[i] << std::endl;
	}
}

//Here unlike the above the parameter type is different. Here we have a vector within a vector as a parameter hence the argument provided to give value to this parameter should be a vector within a vector
void print(const vector<vector<double>>& c) {
	for (int i = 0; i < c.size(); ++i) {
		print(c[i]); //Argument for print() should be a vector indexing a nested vector we get a vector; Aka elements of vector c are vectors; We call print() function above with elements of vector c which are vectors themselves
	} //For each iteration of the loop we call the first print() function arguments are each element of the nested vector/matrix which is a vector itself aka a whole column
	cout << std::endl;
}

//Printing out each element of the vector we get vectors as c's elements are vectors themselves



#endif