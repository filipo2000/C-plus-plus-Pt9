//Objective -> In this file we define all the components within the American Option class

#include "PAmericanOption.h"
#include "pricing.h"
#include <iostream>
#include <cmath>

using namespace std;

//Setting our batch parameters to a default value
//So this is the deafult American Option when we create an American Option class object using the default constructor
PAmericanOption::PAmericanOption() {
	r = 0.08;
	sig = 0.03;
	K = 65;
	b = 0.02;
	opttype = "C";
}


PAmericanOption::PAmericanOption(double K_c, double sig_c, double r_c, double b_c, string str) {
	K = K_c;
	r = r_c;
	sig = sig_c;
	b = b_c;
	opttype = str;
}

PAmericanOption::PAmericanOption(double K_c, double sig_c, double r_c, double b_c) {

	Optionstruct = new OptionData;
	Optionstruct->K_s = K_c;
	Optionstruct->sig_s = sig_c;
	Optionstruct->r_s = r_c;
	Optionstruct->b_s = b_c;
	opttype = "C";

}


PAmericanOption::PAmericanOption(const PAmericanOption& o2)
{
	r = o2.r;
	sig = o2.sig;
	K = o2.K;
	b = o2.b;
	opttype = o2.opttype;
}


PAmericanOption::~PAmericanOption()
{

}


PAmericanOption& PAmericanOption::operator = (const PAmericanOption& option2)
{

	if (this == &option2) return *this;

	PAmericanOption::PAmericanOption(option2);

	return *this;
}

double PAmericanOption::CallPrice(double S) const
{

	return PerpetualCall(K, S, sig, r, b);

}

double PAmericanOption::PutPrice(double S) const
{
	return PerpetualPut(K, S, sig, r, b); //Try PerpetualCall() instead
}


//These are our Struct Calling Functions
double PAmericanOption::Call_Price_Struct(double S) const {
	return PerpetualCall(S, (*this).Optionstruct); //Calling PerpetualCall() with pointer as parameter
}

double PAmericanOption::Put_Price_Struct(double S) const {
	return PerpetualPut(S, (*this).Optionstruct);
}


// Functions that calculate option price and sensitivities
double PAmericanOption::Price(double U) const
{


	if (opttype == "C")
	{
		return CallPrice(U);
	}
	else
	{
		return PutPrice(U);
	}
}


// Modifier functions
void PAmericanOption::toggle()
{ // Change option type (C/P, P/C)

	if (opttype == "C") //If we have a call then switch it to put option type a vice versa
		opttype = "P";
	else
		opttype = "C";
}