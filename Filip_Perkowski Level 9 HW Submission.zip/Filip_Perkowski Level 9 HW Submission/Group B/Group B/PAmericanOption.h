#pragma once

//Objective -> In this file we declare all the components in our American Option Class

#ifndef PAmerican_Option_HPP
#define PAmerican_Option_HPP

#include <string>
using namespace std;

//Our AmericanOption class will be similar to our European Option Class
class PAmericanOption {


	//Same parameters in our batches in our American Options like our European Options
private:
	double r; //Risk free interest rate
	double sig; //Volatility
	double K;
	double b;
	string opttype; //Option Type (Call or Put)



public: //Will use a struct like I did in Eu Option
	struct OptionData {
		double K_s;
		double r_s;
		double sig_s;
		double b_s;
	};

	OptionData* Optionstruct; //This is a pointer which points to a object of struct Option Data type

	//Now creating our constructors, functions etc.
	PAmericanOption();

	PAmericanOption(double K, double sig, double r, double b, string str); //Otherwise try PAmericanOption::PAmericanOption

	PAmericanOption(double K_c, double sig_c, double r_c, double b_c);

	PAmericanOption(const PAmericanOption& c);

	virtual ~PAmericanOption();

	PAmericanOption& operator=(const PAmericanOption& c);

	double Price(double U) const; //Finds price of our underlying PAmericanOption object

	void toggle();

	double CallPrice(double U) const;
	double PutPrice(double U) const;

	double Call_Price_Struct(double S) const; 
	double Put_Price_Struct(double S) const;  

};




#endif